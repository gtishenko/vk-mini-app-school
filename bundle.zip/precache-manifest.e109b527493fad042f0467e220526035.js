self.__precacheManifest = [
  {
    "revision": "968f679e6aa0ca6730f5",
    "url": "/static/css/main.394d46a7.chunk.css"
  },
  {
    "revision": "968f679e6aa0ca6730f5",
    "url": "/static/js/main.4e266dbd.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "be1c07484effd951f28e",
    "url": "/static/css/2.1f4327a6.chunk.css"
  },
  {
    "revision": "be1c07484effd951f28e",
    "url": "/static/js/2.b88a6963.chunk.js"
  },
  {
    "revision": "5cb440f1ab085c0df8441399b0d9647c",
    "url": "/index.html"
  }
];